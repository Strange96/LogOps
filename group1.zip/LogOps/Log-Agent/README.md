# Log-Agent
An agent to be installed on a client computer, to collect and send logs to the service
