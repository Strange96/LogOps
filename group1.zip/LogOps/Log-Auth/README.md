# Log-Auth
An authorization service, used to verify incoming logs from legitimate senders.
