# Log-Website
A very beautiful web interface to access and manage logs and log parsers
