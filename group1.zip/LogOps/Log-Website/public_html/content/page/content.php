<div class="container GLOBALdesign">
        <div class="row">
            <div class="col-sm-12">
                <?php
                    echo $date_from_db_page_text;
                ?>
            </div>
        </div>
</div>