<div>
<?php
// It's posible to make a msg on all pages if somethin is insert here

?>
</div>