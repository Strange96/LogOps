<?php
/*
This is the languages file for standart msg in the CMS.
*/

$lang_data_error = "Der er sket en fejl";
$lang_data_not_elements_found = "Ingen elementer er fundet";
$lang_data_must_be_filled = "Skal udfyldes";
$lang_data_msg_is_sent = "Din besked er sendt";
$lang_data_msg_not_sent = "Du skal venter 30 sekunder for du kan sende en ny besked";
$lang_data_input_to_long = "For mange tegn, maks tegn: ";
$lang_data_input_not_valid_mail = "Ikke godkendt E-mail adresse";

$lang_data_name = "Navn";
$lang_data_country = "Land";
$lang_data_adress = "Adresse";
$lang_data_city = "By";
$lang_data_postcode = "Postnummer";
$lang_data_comment = "Kommentar";
$lang_data_phone = "Telefon nummer";
$lang_data_mail = "Mail";

// Special sentences under here - - - - - - - - - - 
?>