<?php
/*
This is the languages file for standart msg in the CMS.
*/

$lang_data_error = "An error occurred";
$lang_data_not_elements_found = "No elements found";
$lang_data_must_be_filled = "must be filled in";
$lang_data_msg_is_sent = "Your message is sent";
$lang_data_msg_not_sent = "You have to wait 30 seconds to send another message";
$lang_data_input_to_long = "To many characters, max characters: ";
$lang_data_input_not_valid_mail = "Not a valid email adress";

$lang_data_name = "Name";
$lang_data_country = "Country";
$lang_data_adress = "Adress";
$lang_data_city = "City";
$lang_data_postcode = "Post code";
$lang_data_comment = "Comment";
$lang_data_phone = "Phone number";
$lang_data_mail = "Mail";

// Special sentences under here - - - - - - - - - - 
?>