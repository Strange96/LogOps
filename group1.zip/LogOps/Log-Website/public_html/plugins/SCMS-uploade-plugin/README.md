# SCMS-hello-plugin  
  
@plug-in_name:  Uploade plugin  
@author:        Jørn Guldberg  
@Version:       0.0.1  
@main-core:     5.0.0  
@Desciption:    An uploade plugin that has the needed code for  
                a simple upload fucniton 
  
